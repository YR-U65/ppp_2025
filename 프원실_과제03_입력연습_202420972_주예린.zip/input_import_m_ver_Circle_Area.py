import math

r = int(input("원의 반지름을 입력하세요: "))
p = math.pi
area = p*(r**2)


print(area)