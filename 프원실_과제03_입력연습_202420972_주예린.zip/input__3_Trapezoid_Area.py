
#input 3번 사용해서 사다리꼴 넓이 구하기기


top = int(input("윗변의 길이를 입력하세요: "))
base = int(input("아랫변의 길이를 입력하세요: "))
height = int(input("높이를 입력하세요: "))

area = (base+top)*height*0.5

print(area)